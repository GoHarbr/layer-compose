http://richardartoul.github.io/jekyll/update/2015/04/26/hidden-classes.html
