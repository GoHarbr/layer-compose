export let a = 0

export function incA() {
    a += 1
}
