export default {
    sayKey($,_) {
        _.console(_.key)
    }
}
