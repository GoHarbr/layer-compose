/*
* Options (function arguments) are passed like this
* */

/*
* They can have a default preset (which can be used for override-like pattern)
* */

describe("Passing options")
